// DEPRECATED API v1
const OLD_JWT_SECRET = "phantom_old_secret_2022_DO_NOT_USE";
const OLD_ADMIN_KEY = "PHANTOM_ADMIN_LEGACY_KEY_REVOKED";
// All routes disabled
