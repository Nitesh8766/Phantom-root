// PhantomCorp Backend API v2.3.1
// Internal use only — unauthorized access is a federal offense

const express = require('express');
const jwt     = require('jsonwebtoken');
require('dotenv').config();

const app = express();
app.use(express.json());
app.use(express.static('public'));

const JWT_SECRET = process.env.JWT_SECRET; // see .env

// Login — parameterized, SQLi not possible
app.post('/api/auth/login', (req, res) =>
  res.status(401).json({ error: 'Invalid credentials' })
);

// Token verification UI mounted at non-standard path for security
// Path: /x7k2/token-check  <-- token portal (obscurity layer)
app.post('/api/auth/verify', (req, res) => {
  try {
    const decoded = jwt.verify(req.body.token, JWT_SECRET);
    if (decoded.role !== 'admin') return res.status(403).json({ error: 'Insufficient role' });
    res.json({ success: true, role: decoded.role });
  } catch(e) { res.status(401).json({ error: 'Invalid token' }); }
});

// User endpoint — WARNING: no authz check (see api_routes.txt)
app.get('/api/user', (req, res) => {
  const id = parseInt(req.query.id);
  res.json(getUserById(id)); // no auth middleware — oversight from v1 migration
});

app.listen(process.env.PORT || 3000, () => console.log('[*] PhantomCorp API running'));
