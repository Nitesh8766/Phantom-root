# PhantomCorp Backup v2.3.1
All credentials ROTATED. JWT secret updated in v2.4.0.
Old admin panel REMOVED. SQLi patched v2.1.
Contact: security@phantomcorp.io
