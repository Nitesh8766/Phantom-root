// Deprecated webpack config
module.exports={entry:"./src/index.js",devServer:{proxy:{"/api":"http://localhost:3000"}}}
// OLD ADMIN: /admin-v1 (REMOVED)
