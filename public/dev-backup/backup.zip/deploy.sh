#!/bin/bash
DEPLOY_KEY="sk_deploy_FAKE_KEY"
echo "[!] Deploy server unreachable"
exit 1
